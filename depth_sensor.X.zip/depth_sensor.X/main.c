/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.78
        Device            :  PIC18F26K22
        Driver Version    :  2.00
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#include "mcc_generated_files/mcc.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
void data(char *bits, uint16_t len);
bool isshort(unsigned int t);
bool islong(unsigned int t);
char bin(unsigned int k);
void bitsttobyte(int bitlen, char *bits,unsigned char *result);
void reversenibbles(char *bits, int bitLen, char *rBits);
unsigned char getnibble(unsigned char *message, unsigned int nibblePos);
signed int gettemp();
unsigned int getdepth();
unsigned char bindata[240];
char rBits[240];
unsigned char message[9];
/*
                         Main application
 */
void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();

    // If using interrupts in PIC18 High/Low Priority Mode you need to enable the Global High and Low Interrupts
    // If using interrupts in PIC Mid-Range Compatibility Mode you need to enable the Global and Peripheral Interrupts
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

   // Enable the Peripheral Interrupts
    INTERRUPT_PeripheralInterruptEnable();
      char output_val[200];
      int dif=0;
      int size=0;
      int flag=0;
      float temp=0;
    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
  while(1)
   {
          memset(timingarray, 0, 480);
          memset(diffarray, 0, 480);
          memset(bindata, 0, 240);
        while(!int_start)
        {
            __delay_ms(5);
        }
          EUSART1_Write_string("\r\nintr start\r\n", 14);
        while(int_stop < 10)
        {
            int_stop++;
            __delay_ms(5);
        }
         int_start = 0;
        int_stop = 0;
        for(int j=0;j<i;j++)
        {
             if(timingarray[j+1]<timingarray[j])
             dif = (65536-timingarray[j])+timingarray[j+1];
             else
              dif=(timingarray[j+1]-timingarray[j]);
            
              diffarray[j] = dif;
             
          }
        data(bindata, i);
        size=strlen(bindata);
        flag=1;
              
        EUSART1_Write_string("\r\nRecord end\r\n", 12);
        i=0;
        
     if(flag==1)
       {
      
          if(size<=72)
            {
              EUSART1_Write_string("\r\nwait for next packet\r\n", 24);   
            }
          else if(size>=72)
            {  
               //EUSART1_Write_string(bindata,72);
               for(int j=72;j>0;j--)
               {
                 bindata[j]=bindata[j-1];   
               }
              bindata[0]='0';
           
              reversenibbles(bindata,72, rBits);
              if(rBits[0]==1 && rBits[1]==0 && rBits[2]==1 && rBits[3]==0 && rBits[4]==1 && rBits[5]==1 && rBits[6]==1 && rBits[7]==1  )
               {
                  EUSART1_Write_string(rBits,72);
                  bitsttobyte(strlen(rBits), rBits, message);
                  //temp = (gettemp()/10);
            
                  sprintf(output_val," %d",gettemp());
                  //EUSART1_Write_string("\r\nTemprature\r\n",12);
                  //__delay_ms(5);
                  //EUSART1_Write_string(output_val,strlen(output_val));
               }
            }
          else if(size==72)
            {
               //char temp;
             for(int j=72;j>0;j--)
               {
                 bindata[j]=bindata[j-1];   
               }
               bindata[0]='0';
             
               reversenibbles(bindata,strlen(bindata), rBits);
               if(rBits[0]==1 && rBits[1]==0 && rBits[2]==1 && rBits[3]==0 && rBits[4]==1 && rBits[5]==1 && rBits[6]==1 && rBits[7]==1)
               { 
                  EUSART1_Write_string(rBits,72);
                 bitsttobyte(strlen(rBits), rBits, message);
                 //temp = (gettemp()/10);
           
                 sprintf(output_val," %d",gettemp());
                 //EUSART1_Write_string("\r\nTemprature\r\n",12);
                 //__delay_ms(10);
                  //EUSART1_Write_string(output_val,strlen(output_val));
               }
            }
         flag=0;
         
        }
        
        
     
   }
      
  
}


void data(char *bits, uint16_t len){
    
    for(int k=0;k<len;k=k+1)
    {
        bits[k]=bin(diffarray[k]);
        
    }
    
}

bool isshort(unsigned int t) {
        if ((abs(t-960)<= 100))
               return true;
        return false;
}

bool islong(unsigned int t) {
        if ((abs(t-1440) <= 100))
              return true;
        return false;
}

 char bin(unsigned int k){
    if(isshort(k))
      return'0';
    else if(islong(k))
      return'1';
       
    return'.';
     
}

void reversenibbles(char *bits, int bitLen, char *rBits) {
        int rBitPos = 0;
        for (int i = 0; i < bitLen / 4; i++)
        {
             rBits[rBitPos++] = bits[(i * 4) + 3];
             rBits[rBitPos++] = bits[(i * 4) + 2];
             rBits[rBitPos++] = bits[(i * 4) + 1];
             rBits[rBitPos++] = bits[(i * 4) + 0];
        }
}


void bitsttobyte(int bitlen, char *bits,unsigned char *result) {
                               
        for (int i = 0; i < bitlen; i++) 
        {
                result[(i / 8)] *= 2; 
                if (bits[i] == '1')
                     result[(i / 8)]++; 
        }
}



unsigned char getnibble(unsigned char *message, unsigned int nibblePos) {
        if ((nibblePos % 2) == 0) 
         {
                return (message[nibblePos / 2] >> 4) & 0x0f;
         } 
        else 
         {
                return (message[nibblePos / 2] ) & 0x0f;
         }
}

signed int gettemp() 
{
       unsigned char *message = message;
        signed int result = 0;

        result = (result | getnibble(message, 13)) << 4;
        result = (result | getnibble(message, 12)) << 4;
        result = (result | getnibble(message, 10));
        if (result >= 400 && result <= 1000 ) return result - 400;
            
        return -20;
}

unsigned int getdepth() 
{
        unsigned char *message = message;
        unsigned int result = 0;

        result = (result | getnibble(message, 7)) << 4;
        result = (result | getnibble(message, 6)) << 4;
        result = (result | getnibble(message, 8));
        return result;
}

